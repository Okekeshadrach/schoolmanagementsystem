function test(a) {
  var x = document.getElementById("select_id").value
  var cmdery
//   console.log(x)

  if (x == "St. Paul, Issele Uku") {
    cmdery = "462"
  } else if (x == "Secred Heart, Warri") {
    cmdery = "489"
  } else if (x == "St. Patrick, Benin City") {
    cmdery = "494"
  } else if (x == "CKC, Obiaruku") {
    cmdery = "549"
  } else if (x == "St. Patrick's, Asaba") {
    cmdery = "550"
  } else if (x == "St. John De Baptist, Agbor") {
    cmdery = "551"
  } else if (x == "St. Joseph, Benin City") {
    cmdery = "552"
  } else if (x == "St. Anthony, Auchi") {
    cmdery = "553"
  } else if (x == "Secred Heart, Abraka") {
    cmdery = "554"
  } else if (x == "St. Dominic, Benin City") {
    cmdery = "555"
  } else if (x == "St. Jude, Uromi") {
    cmdery = "556"
  } else if (x == "St. Peter & Paul, Ugheli") {
    cmdery = "598"
  } else if (x == "St. Patrick, Sapele") {
    cmdery = "599"
  } else if (x == "St. Francis, Benin City") {
    cmdery = "717"
  } else if (x == "St. Micheal, Fugar") {
    cmdery = "719"
  } else if (x == "St. Joseph, Eme Ora") {
    cmdery = "720"
  } else if (x == "St. Maria Goritti, Benin City") {
    cmdery = "722"
  } else if (x == "St. Peter, Benin") {
    cmdery = "724"
  } else if (x == "St. Micheal, Benin City") {
    cmdery = "725"
  } else if (x == "St. Micheal, DSC") {
    cmdery = "728"
  } else if (x == "Mother of the Redeemer, Warri") {
    cmdery = "729"
  } else if (x == "St. Anthony, Ugborikoko") {
    cmdery = "730"
  } else if (x == "Mary Immaculate, Ogwashi-Uku") {
    cmdery = "731"
  } else if (x == "St. Benedict, Ekpoma") {
    cmdery = "732"
  } else if (x == "St. Jude, Iwogban-Benin City") {
    cmdery = "733"
  } else if (x == "St. Joseph, Asaba") {
    cmdery = "859"
  } else if (x == "St. Albert De Great, Asaba") {
    cmdery = "860"
  } else if (x == "St. Bridgids, Asaba") {
    cmdery = "861"
  } else if (x == "St. Peter & Paul, Asaba") {
    cmdery = "862"
  } else if (x == "Ascension, Asaba") {
    cmdery = "863"
  } else if (x == "St. John Mary Vianney, Asaba") {
    cmdery = "864"
  } else if (x == "St. Micheal, Okpanam") {
    cmdery = "865"
  } else if (x == "Assumption, Zappa-Asaba") {
    cmdery = "893"
  } else if (x == "St. Peter, Ekete") {
    cmdery = "897"
  } else if (x == "Holy Spirit, Ugheli") {
    cmdery = "938"
  } else if (x == "St. John De Baptist, Oleh") {
    cmdery = "939"
  } else if (x == "St. Gregory, Agbarho") {
    cmdery = "940"
  } else if (x == "St. Augustine, Ibusa") {
    cmdery = "941"
  }
//   console.log(cmdery)
  document.getElementById("cmdery").value = cmdery
}
